using LogicAPI.Server;
using LogicLog;

namespace binarry_to_hexedecemal
{
    public class binarry_to_hexedecemal : ServerMod
    {
        protected override void Initialize()
        {
            Logger.Info("binarry to hexedecemal mod loaded successfully!");
        }
    }
}