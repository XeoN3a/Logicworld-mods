using LogicAPI.Server.Components;

namespace binarry_to_hexedecemal.Components
{
    public class bit8_to_hex : LogicComponent
    {
        // outputs
        // 10 11 12  23 24 25
        //  8     9  21    22
        //  5  6  7  18 19 20
        //  3     4  16    17
        //  0  1  2  13 14 15

        // inputs
        // 0 1 2 3 4 5 6 7

        private int p0;
        private int p1;
        private int p2;
        private int p3;
        private int p4;
        private int p5;
        private int p6;
        private int p7;

        private int pr;

        private int h1;
        private int h2;

        protected override void DoLogicUpdate()
        {
            p0 = Inputs[0].On ? 1 : 0;
            p1 = Inputs[1].On ? 2 : 0;
            p2 = Inputs[2].On ? 4 : 0;
            p3 = Inputs[3].On ? 8 : 0;
            p4 = Inputs[4].On ? 16 : 0;
            p5 = Inputs[5].On ? 32 : 0;
            p6 = Inputs[6].On ? 64 : 0;
            p7 = Inputs[7].On ? 128 : 0;

            pr = p0 + p1 + p2 + p3 + p4 + p5 + p6 + p7;

            if (pr == 0) { h1 = 0; h2 = 0; }
            if (pr == 1) { h1 = 1; h2 = 0; }
            if (pr == 2) { h1 = 2; h2 = 0; }
            if (pr == 3) { h1 = 3; h2 = 0; }
            if (pr == 4) { h1 = 4; h2 = 0; }
            if (pr == 5) { h1 = 5; h2 = 0; }
            if (pr == 6) { h1 = 6; h2 = 0; }
            if (pr == 7) { h1 = 7; h2 = 0; }
            if (pr == 8) { h1 = 8; h2 = 0; }
            if (pr == 9) { h1 = 9; h2 = 0; }
            if (pr == 10) { h1 = 10; h2 = 0; }
            if (pr == 11) { h1 = 11; h2 = 0; }
            if (pr == 12) { h1 = 12; h2 = 0; }
            if (pr == 13) { h1 = 13; h2 = 0; }
            if (pr == 14) { h1 = 14; h2 = 0; }
            if (pr == 15) { h1 = 15; h2 = 0; }

            if (pr == 16) { h1 = 0; h2 = 1; }
            if (pr == 17) { h1 = 1; h2 = 1; }
            if (pr == 18) { h1 = 2; h2 = 1; }
            if (pr == 19) { h1 = 3; h2 = 1; }
            if (pr == 20) { h1 = 4; h2 = 1; }
            if (pr == 21) { h1 = 5; h2 = 1; }
            if (pr == 22) { h1 = 6; h2 = 1; }
            if (pr == 23) { h1 = 7; h2 = 1; }
            if (pr == 24) { h1 = 8; h2 = 1; }
            if (pr == 25) { h1 = 9; h2 = 1; }
            if (pr == 26) { h1 = 10; h2 = 1; }
            if (pr == 27) { h1 = 11; h2 = 1; }
            if (pr == 28) { h1 = 12; h2 = 1; }
            if (pr == 29) { h1 = 13; h2 = 1; }
            if (pr == 30) { h1 = 14; h2 = 1; }
            if (pr == 31) { h1 = 15; h2 = 1; }

            if (pr == 32) { h1 = 0; h2 = 2; }
            if (pr == 33) { h1 = 1; h2 = 2; }
            if (pr == 34) { h1 = 2; h2 = 2; }
            if (pr == 35) { h1 = 3; h2 = 2; }
            if (pr == 36) { h1 = 4; h2 = 2; }
            if (pr == 37) { h1 = 5; h2 = 2; }
            if (pr == 38) { h1 = 6; h2 = 2; }
            if (pr == 39) { h1 = 7; h2 = 2; }
            if (pr == 40) { h1 = 8; h2 = 2; }
            if (pr == 41) { h1 = 9; h2 = 2; }
            if (pr == 42) { h1 = 10; h2 = 2; }
            if (pr == 43) { h1 = 11; h2 = 2; }
            if (pr == 44) { h1 = 12; h2 = 2; }
            if (pr == 45) { h1 = 13; h2 = 2; }
            if (pr == 46) { h1 = 14; h2 = 2; }
            if (pr == 47) { h1 = 15; h2 = 2; }

            if (pr == 48) { h1 = 0; h2 = 3; }
            if (pr == 49) { h1 = 1; h2 = 3; }
            if (pr == 50) { h1 = 2; h2 = 3; }
            if (pr == 51) { h1 = 3; h2 = 3; }
            if (pr == 52) { h1 = 4; h2 = 3; }
            if (pr == 53) { h1 = 5; h2 = 3; }
            if (pr == 54) { h1 = 6; h2 = 3; }
            if (pr == 55) { h1 = 7; h2 = 3; }
            if (pr == 56) { h1 = 8; h2 = 3; }
            if (pr == 57) { h1 = 9; h2 = 3; }
            if (pr == 58) { h1 = 10; h2 = 3; }
            if (pr == 59) { h1 = 11; h2 = 3; }
            if (pr == 60) { h1 = 12; h2 = 3; }
            if (pr == 61) { h1 = 13; h2 = 3; }
            if (pr == 62) { h1 = 14; h2 = 3; }
            if (pr == 63) { h1 = 15; h2 = 3; }

            if (pr == 64) { h1 = 0; h2 = 4; }
            if (pr == 65) { h1 = 1; h2 = 4; }
            if (pr == 66) { h1 = 2; h2 = 4; }
            if (pr == 67) { h1 = 3; h2 = 4; }
            if (pr == 68) { h1 = 4; h2 = 4; }
            if (pr == 69) { h1 = 5; h2 = 4; }
            if (pr == 70) { h1 = 6; h2 = 4; }
            if (pr == 71) { h1 = 7; h2 = 4; }
            if (pr == 72) { h1 = 8; h2 = 4; }
            if (pr == 73) { h1 = 9; h2 = 4; }
            if (pr == 74) { h1 = 10; h2 = 4; }
            if (pr == 75) { h1 = 11; h2 = 4; }
            if (pr == 76) { h1 = 12; h2 = 4; }
            if (pr == 77) { h1 = 13; h2 = 4; }
            if (pr == 78) { h1 = 14; h2 = 4; }
            if (pr == 79) { h1 = 15; h2 = 4; }

            if (pr == 80) { h1 = 0; h2 = 5; }
            if (pr == 81) { h1 = 1; h2 = 5; }
            if (pr == 82) { h1 = 2; h2 = 5; }
            if (pr == 83) { h1 = 3; h2 = 5; }
            if (pr == 84) { h1 = 4; h2 = 5; }
            if (pr == 85) { h1 = 5; h2 = 5; }
            if (pr == 86) { h1 = 6; h2 = 5; }
            if (pr == 87) { h1 = 7; h2 = 5; }
            if (pr == 88) { h1 = 8; h2 = 5; }
            if (pr == 89) { h1 = 9; h2 = 5; }
            if (pr == 90) { h1 = 10; h2 = 5; }
            if (pr == 91) { h1 = 11; h2 = 5; }
            if (pr == 92) { h1 = 12; h2 = 5; }
            if (pr == 93) { h1 = 13; h2 = 5; }
            if (pr == 94) { h1 = 14; h2 = 5; }
            if (pr == 95) { h1 = 15; h2 = 5; }

            if (pr == 96) { h1 = 0; h2 = 6; }
            if (pr == 97) { h1 = 1; h2 = 6; }
            if (pr == 98) { h1 = 2; h2 = 6; }
            if (pr == 99) { h1 = 3; h2 = 6; }
            if (pr == 100) { h1 = 4; h2 = 6; }
            if (pr == 101) { h1 = 5; h2 = 6; }
            if (pr == 102) { h1 = 6; h2 = 6; }
            if (pr == 103) { h1 = 7; h2 = 6; }
            if (pr == 104) { h1 = 8; h2 = 6; }
            if (pr == 105) { h1 = 9; h2 = 6; }
            if (pr == 106) { h1 = 10; h2 = 6; }
            if (pr == 107) { h1 = 11; h2 = 6; }
            if (pr == 108) { h1 = 12; h2 = 6; }
            if (pr == 109) { h1 = 13; h2 = 6; }
            if (pr == 110) { h1 = 14; h2 = 6; }
            if (pr == 111) { h1 = 15; h2 = 6; }

            if (pr == 112) { h1 = 0; h2 = 7; }
            if (pr == 113) { h1 = 1; h2 = 7; }
            if (pr == 114) { h1 = 2; h2 = 7; }
            if (pr == 115) { h1 = 3; h2 = 7; }
            if (pr == 116) { h1 = 4; h2 = 7; }
            if (pr == 117) { h1 = 5; h2 = 7; }
            if (pr == 118) { h1 = 6; h2 = 7; }
            if (pr == 119) { h1 = 7; h2 = 7; }
            if (pr == 120) { h1 = 8; h2 = 7; }
            if (pr == 121) { h1 = 9; h2 = 7; }
            if (pr == 122) { h1 = 10; h2 = 7; }
            if (pr == 123) { h1 = 11; h2 = 7; }
            if (pr == 124) { h1 = 12; h2 = 7; }
            if (pr == 125) { h1 = 13; h2 = 7; }
            if (pr == 126) { h1 = 14; h2 = 7; }
            if (pr == 127) { h1 = 15; h2 = 7; }

            if (pr == 128) { h1 = 0; h2 = 8; }
            if (pr == 129) { h1 = 1; h2 = 8; }
            if (pr == 130) { h1 = 2; h2 = 8; }
            if (pr == 131) { h1 = 3; h2 = 8; }
            if (pr == 132) { h1 = 4; h2 = 8; }
            if (pr == 133) { h1 = 5; h2 = 8; }
            if (pr == 134) { h1 = 6; h2 = 8; }
            if (pr == 135) { h1 = 7; h2 = 8; }
            if (pr == 136) { h1 = 8; h2 = 8; }
            if (pr == 137) { h1 = 9; h2 = 8; }
            if (pr == 138) { h1 = 10; h2 = 8; }
            if (pr == 139) { h1 = 11; h2 = 8; }
            if (pr == 140) { h1 = 12; h2 = 8; }
            if (pr == 141) { h1 = 13; h2 = 8; }
            if (pr == 142) { h1 = 14; h2 = 8; }
            if (pr == 143) { h1 = 15; h2 = 8; }

            if (pr == 144) { h1 = 0; h2 = 9; }
            if (pr == 145) { h1 = 1; h2 = 9; }
            if (pr == 146) { h1 = 2; h2 = 9; }
            if (pr == 147) { h1 = 3; h2 = 9; }
            if (pr == 148) { h1 = 4; h2 = 9; }
            if (pr == 149) { h1 = 5; h2 = 9; }
            if (pr == 150) { h1 = 6; h2 = 9; }
            if (pr == 151) { h1 = 7; h2 = 9; }
            if (pr == 152) { h1 = 8; h2 = 9; }
            if (pr == 153) { h1 = 9; h2 = 9; }
            if (pr == 154) { h1 = 10; h2 = 9; }
            if (pr == 155) { h1 = 11; h2 = 9; }
            if (pr == 156) { h1 = 12; h2 = 9; }
            if (pr == 157) { h1 = 13; h2 = 9; }
            if (pr == 158) { h1 = 14; h2 = 9; }
            if (pr == 159) { h1 = 15; h2 = 9; }

            if (pr == 160) { h1 = 0; h2 = 10; }
            if (pr == 161) { h1 = 1; h2 = 10; }
            if (pr == 162) { h1 = 2; h2 = 10; }
            if (pr == 163) { h1 = 3; h2 = 10; }
            if (pr == 164) { h1 = 4; h2 = 10; }
            if (pr == 165) { h1 = 5; h2 = 10; }
            if (pr == 166) { h1 = 6; h2 = 10; }
            if (pr == 167) { h1 = 7; h2 = 10; }
            if (pr == 168) { h1 = 8; h2 = 10; }
            if (pr == 169) { h1 = 9; h2 = 10; }
            if (pr == 170) { h1 = 10; h2 = 10; }
            if (pr == 171) { h1 = 11; h2 = 10; }
            if (pr == 172) { h1 = 12; h2 = 10; }
            if (pr == 173) { h1 = 13; h2 = 10; }
            if (pr == 174) { h1 = 14; h2 = 10; }
            if (pr == 175) { h1 = 15; h2 = 10; }

            if (pr == 176) { h1 = 0; h2 = 11; }
            if (pr == 177) { h1 = 1; h2 = 11; }
            if (pr == 178) { h1 = 2; h2 = 11; }
            if (pr == 179) { h1 = 3; h2 = 11; }
            if (pr == 180) { h1 = 4; h2 = 11; }
            if (pr == 181) { h1 = 5; h2 = 11; }
            if (pr == 182) { h1 = 6; h2 = 11; }
            if (pr == 183) { h1 = 7; h2 = 11; }
            if (pr == 184) { h1 = 8; h2 = 11; }
            if (pr == 185) { h1 = 9; h2 = 11; }
            if (pr == 186) { h1 = 10; h2 = 11; }
            if (pr == 187) { h1 = 11; h2 = 11; }
            if (pr == 188) { h1 = 12; h2 = 11; }
            if (pr == 189) { h1 = 13; h2 = 11; }
            if (pr == 190) { h1 = 14; h2 = 11; }
            if (pr == 191) { h1 = 15; h2 = 11; }

            if (pr == 192) { h1 = 0; h2 = 12; }
            if (pr == 193) { h1 = 1; h2 = 12; }
            if (pr == 194) { h1 = 2; h2 = 12; }
            if (pr == 195) { h1 = 3; h2 = 12; }
            if (pr == 196) { h1 = 4; h2 = 12; }
            if (pr == 197) { h1 = 5; h2 = 12; }
            if (pr == 198) { h1 = 6; h2 = 12; }
            if (pr == 199) { h1 = 7; h2 = 12; }
            if (pr == 200) { h1 = 8; h2 = 12; }
            if (pr == 201) { h1 = 9; h2 = 12; }
            if (pr == 202) { h1 = 10; h2 = 12; }
            if (pr == 203) { h1 = 11; h2 = 12; }
            if (pr == 204) { h1 = 12; h2 = 12; }
            if (pr == 205) { h1 = 13; h2 = 12; }
            if (pr == 206) { h1 = 14; h2 = 12; }
            if (pr == 207) { h1 = 15; h2 = 12; }

            if (pr == 208) { h1 = 0; h2 = 13; }
            if (pr == 209) { h1 = 1; h2 = 13; }
            if (pr == 210) { h1 = 2; h2 = 13; }
            if (pr == 211) { h1 = 3; h2 = 13; }
            if (pr == 212) { h1 = 4; h2 = 13; }
            if (pr == 213) { h1 = 5; h2 = 13; }
            if (pr == 214) { h1 = 6; h2 = 13; }
            if (pr == 215) { h1 = 7; h2 = 13; }
            if (pr == 216) { h1 = 8; h2 = 13; }
            if (pr == 217) { h1 = 9; h2 = 13; }
            if (pr == 218) { h1 = 10; h2 = 13; }
            if (pr == 219) { h1 = 11; h2 = 13; }
            if (pr == 220) { h1 = 12; h2 = 13; }
            if (pr == 221) { h1 = 13; h2 = 13; }
            if (pr == 222) { h1 = 14; h2 = 13; }
            if (pr == 223) { h1 = 15; h2 = 13; }

            if (pr == 224) { h1 = 0; h2 = 14; }
            if (pr == 225) { h1 = 1; h2 = 14; }
            if (pr == 226) { h1 = 2; h2 = 14; }
            if (pr == 227) { h1 = 3; h2 = 14; }
            if (pr == 228) { h1 = 4; h2 = 14; }
            if (pr == 229) { h1 = 5; h2 = 14; }
            if (pr == 230) { h1 = 6; h2 = 14; }
            if (pr == 231) { h1 = 7; h2 = 14; }
            if (pr == 232) { h1 = 8; h2 = 14; }
            if (pr == 233) { h1 = 9; h2 = 14; }
            if (pr == 234) { h1 = 10; h2 = 14; }
            if (pr == 235) { h1 = 11; h2 = 14; }
            if (pr == 236) { h1 = 12; h2 = 14; }
            if (pr == 237) { h1 = 13; h2 = 14; }
            if (pr == 238) { h1 = 14; h2 = 14; }
            if (pr == 239) { h1 = 15; h2 = 14; }

            if (pr == 240) { h1 = 0; h2 = 15; }
            if (pr == 241) { h1 = 1; h2 = 15; }
            if (pr == 242) { h1 = 2; h2 = 15; }
            if (pr == 243) { h1 = 3; h2 = 15; }
            if (pr == 244) { h1 = 4; h2 = 15; }
            if (pr == 245) { h1 = 5; h2 = 15; }
            if (pr == 246) { h1 = 6; h2 = 15; }
            if (pr == 247) { h1 = 7; h2 = 15; }
            if (pr == 248) { h1 = 8; h2 = 15; }
            if (pr == 249) { h1 = 9; h2 = 15; }
            if (pr == 250) { h1 = 10; h2 = 15; }
            if (pr == 251) { h1 = 11; h2 = 15; }
            if (pr == 252) { h1 = 12; h2 = 15; }
            if (pr == 253) { h1 = 13; h2 = 15; }
            if (pr == 254) { h1 = 14; h2 = 15; }
            if (pr == 255) { h1 = 15; h2 = 15; }

            // outputs
            // 10 11 12  23 24 25
            //  8     9  21    22
            //  5  6  7  18 19 20
            //  3     4  16    17
            //  0  1  2  13 14 15

            bool[][] hex =
            {
                
                new bool[] { true, true, true, true, true, true, false, true, true, true, true, true, true }, //0
                new bool[] { true, false, false, true, false, true, false, false, true, false, true, false, false }, //1
                new bool[] { true, true, true, false, true, true, true, true, true, false, true, true, true }, //2
                new bool[] { true, true, true, true, false, true, true, true, true, false, true, true, true }, //3
                new bool[] { true, false, false, true, false, true, true, true, true, true, true, false, true }, //4
                new bool[] { true, true, true, true, false, true, true, true, false, true, true, true, true }, //5
                new bool[] { true, true, true, true, true, true, true, true, false, true, true, true, true }, //6
                new bool[] { true, false, false, true, false, true, false, false, true, false, true, true, true }, //7
                new bool[] { true, true, true, true, true, true, true, true, true, true, true, true, true }, //8
                new bool[] { true, true, true, true, false, true, true, true, true, true, true, true, true }, //9
                new bool[] { true, false, true, true, true, true, true, true, true, true, false, true, false }, //A
                new bool[] { false, true, true, true, true, false, true, true, true, true, false, true, true }, //B
                new bool[] { false, true, true, true, false, true, false, false, true, false, false, true, true }, //C
                new bool[] { false, true, true, true, true, true, false, true, true, true, false, true, true }, //D
                new bool[] { true, true, true, false, true, true, true, true, false, true, true, true, true }, //E
                new bool[] { false, false, true, false, true, true, true, true, false, true, true, true, true } //F
            };

            for (int i = 0; i < 13; i++)
            {
                Outputs[i].On = hex[h1][i];
                Outputs[i + 13].On = hex[h2][i];
            }

        }
    }
}