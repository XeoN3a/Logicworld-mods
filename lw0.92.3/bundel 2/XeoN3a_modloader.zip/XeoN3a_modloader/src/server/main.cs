using LogicAPI.Server;
using LogicLog;

namespace XeoN3amodloader
{
    public class XeoN3amodloader : ServerMod
    {
        protected override void Initialize()
        {
            Logger.Info("XeoN3a_modloader loaded successfully!");
        }
    }
}