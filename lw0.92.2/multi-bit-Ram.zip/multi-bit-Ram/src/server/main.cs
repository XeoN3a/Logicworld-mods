using LogicAPI.Server;
using LogicLog;

namespace MultiBitRam
{
    public class MultiBitRam : ServerMod
    {
        protected override void Initialize()
        {
            Logger.Info("Multi-bit Ram mod loaded successfully!");
        }
    }
}