using LogicAPI.Server.Components;

namespace multi_bit_ram.Components
{
    public class Ram8Bit4A : LogicComponent
    {
        private bool a0;
        private bool a1;
        private bool a2;
        private bool a3;
        private bool a4;
        private bool a5;
        private bool a6;
        private bool a7;

        private bool b0;
        private bool b1;
        private bool b2;
        private bool b3;
        private bool b4;
        private bool b5;
        private bool b6;
        private bool b7;

        private bool c0;
        private bool c1;
        private bool c2;
        private bool c3;
        private bool c4;
        private bool c5;
        private bool c6;
        private bool c7;

        private bool d0;
        private bool d1;
        private bool d2;
        private bool d3;
        private bool d4;
        private bool d5;
        private bool d6;
        private bool d7;

        private bool e0;
        private bool e1;
        private bool e2;
        private bool e3;
        private bool e4;
        private bool e5;
        private bool e6;
        private bool e7;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 7 = D0 - D7
            // 8 = Enable (top)
            // 00 = a0, 01 = a1, 10 = a2, 11 =a3
            // 9 - 10 = address bits

            if (!Inputs[9].On && !Inputs[10].On)
            {
                if (Inputs[8].On)
                {
                    b0 = Inputs[0].On;
                    b1 = Inputs[1].On;
                    b2 = Inputs[2].On;
                    b3 = Inputs[3].On;
                    b4 = Inputs[4].On;
                    b5 = Inputs[5].On;
                    b6 = Inputs[6].On;
                    b7 = Inputs[7].On;
                }
                a0 = b0;
                a1 = b1;
                a2 = b2;
                a3 = b3;
                a4 = b4;
                a5 = b5;
                a6 = b6;
                a7 = b7;
            }

            if (!Inputs[9].On && Inputs[10].On)
            {
                if (Inputs[8].On)
                {
                    c0 = Inputs[0].On;
                    c1 = Inputs[1].On;
                    c2 = Inputs[2].On;
                    c3 = Inputs[3].On;
                    c4 = Inputs[4].On;
                    c5 = Inputs[5].On;
                    c6 = Inputs[6].On;
                    c7 = Inputs[7].On;
                }
                a0 = c0;
                a1 = c1;
                a2 = c2;
                a3 = c3;
                a4 = c4;
                a5 = c5;
                a6 = c6;
                a7 = c7;
            }

            if (Inputs[9].On && !Inputs[10].On)
            {
                if (Inputs[8].On)
                {
                    d0 = Inputs[0].On;
                    d1 = Inputs[1].On;
                    d2 = Inputs[2].On;
                    d3 = Inputs[3].On;
                    d4 = Inputs[4].On;
                    d5 = Inputs[5].On;
                    d6 = Inputs[6].On;
                    d7 = Inputs[7].On;
                }
                a0 = d0;
                a1 = d1;
                a2 = d2;
                a3 = d3;
                a4 = d4;
                a5 = d5;
                a6 = d6;
                a7 = d7;
            }

            if (Inputs[9].On && Inputs[10].On)
            {
                if (Inputs[8].On)
                {
                    e0 = Inputs[0].On;
                    e1 = Inputs[1].On;
                    e2 = Inputs[2].On;
                    e3 = Inputs[3].On;
                    e4 = Inputs[4].On;
                    e5 = Inputs[5].On;
                    e6 = Inputs[6].On;
                    e7 = Inputs[7].On;
                }
                a0 = e0;
                a1 = e1;
                a2 = e2;
                a3 = e3;
                a4 = e4;
                a5 = e5;
                a6 = e6;
                a7 = e7;
            }

        Outputs[0].On = a0;
        Outputs[1].On = a1;
        Outputs[2].On = a2;
        Outputs[3].On = a3;
        Outputs[4].On = a4;
        Outputs[5].On = a5;
        Outputs[6].On = a6;
        Outputs[7].On = a7;

        }
    }
}