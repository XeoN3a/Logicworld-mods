using LogicAPI.Server.Components;

namespace multi_bit_ram.Components
{
    public class Ram8Bit8A : LogicComponent
    {
        private bool a0;
        private bool a1;
        private bool a2;
        private bool a3;
        private bool a4;
        private bool a5;
        private bool a6;
        private bool a7;

        private bool b0;
        private bool b1;
        private bool b2;
        private bool b3;
        private bool b4;
        private bool b5;
        private bool b6;
        private bool b7;

        private bool c0;
        private bool c1;
        private bool c2;
        private bool c3;
        private bool c4;
        private bool c5;
        private bool c6;
        private bool c7;

        private bool d0;
        private bool d1;
        private bool d2;
        private bool d3;
        private bool d4;
        private bool d5;
        private bool d6;
        private bool d7;

        private bool e0;
        private bool e1;
        private bool e2;
        private bool e3;
        private bool e4;
        private bool e5;
        private bool e6;
        private bool e7;

        private bool f0;
        private bool f1;
        private bool f2;
        private bool f3;
        private bool f4;
        private bool f5;
        private bool f6;
        private bool f7;

        private bool g0;
        private bool g1;
        private bool g2;
        private bool g3;
        private bool g4;
        private bool g5;
        private bool g6;
        private bool g7;

        private bool h0;
        private bool h1;
        private bool h2;
        private bool h3;
        private bool h4;
        private bool h5;
        private bool h6;
        private bool h7;

        private bool i0;
        private bool i1;
        private bool i2;
        private bool i3;
        private bool i4;
        private bool i5;
        private bool i6;
        private bool i7;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 7 = D0 - D7
            // 8 = Enable (top)
            // 9 - 11 = address bits

            if (!Inputs[9].On && !Inputs[10].On && !Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    b0 = Inputs[0].On;
                    b1 = Inputs[1].On;
                    b2 = Inputs[2].On;
                    b3 = Inputs[3].On;
                    b4 = Inputs[4].On;
                    b5 = Inputs[5].On;
                    b6 = Inputs[6].On;
                    b7 = Inputs[7].On;
                }
                a0 = b0;
                a1 = b1;
                a2 = b2;
                a3 = b3;
                a4 = b4;
                a5 = b5;
                a6 = b6;
                a7 = b7;
            }

            if (!Inputs[9].On && !Inputs[10].On && Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    c0 = Inputs[0].On;
                    c1 = Inputs[1].On;
                    c2 = Inputs[2].On;
                    c3 = Inputs[3].On;
                    c4 = Inputs[4].On;
                    c5 = Inputs[5].On;
                    c6 = Inputs[6].On;
                    c7 = Inputs[7].On;
                }
                a0 = c0;
                a1 = c1;
                a2 = c2;
                a3 = c3;
                a4 = c4;
                a5 = c5;
                a6 = c6;
                a7 = c7;
            }

            if (!Inputs[9].On && Inputs[10].On && !Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    d0 = Inputs[0].On;
                    d1 = Inputs[1].On;
                    d2 = Inputs[2].On;
                    d3 = Inputs[3].On;
                    d4 = Inputs[4].On;
                    d5 = Inputs[5].On;
                    d6 = Inputs[6].On;
                    d7 = Inputs[7].On;
                }
                a0 = d0;
                a1 = d1;
                a2 = d2;
                a3 = d3;
                a4 = d4;
                a5 = d5;
                a6 = d6;
                a7 = d7;
            }

            if (!Inputs[9].On && Inputs[10].On && Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    e0 = Inputs[0].On;
                    e1 = Inputs[1].On;
                    e2 = Inputs[2].On;
                    e3 = Inputs[3].On;
                    e4 = Inputs[4].On;
                    e5 = Inputs[5].On;
                    e6 = Inputs[6].On;
                    e7 = Inputs[7].On;
                }
                a0 = e0;
                a1 = e1;
                a2 = e2;
                a3 = e3;
                a4 = e4;
                a5 = e5;
                a6 = e6;
                a7 = e7;
            }

            if (Inputs[9].On && !Inputs[10].On && !Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    f0 = Inputs[0].On;
                    f1 = Inputs[1].On;
                    f2 = Inputs[2].On;
                    f3 = Inputs[3].On;
                    f4 = Inputs[4].On;
                    f5 = Inputs[5].On;
                    f6 = Inputs[6].On;
                    f7 = Inputs[7].On;
                }
                a0 = f0;
                a1 = f1;
                a2 = f2;
                a3 = f3;
                a4 = f4;
                a5 = f5;
                a6 = f6;
                a7 = f7;
            }

            if (Inputs[9].On && !Inputs[10].On && Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    g0 = Inputs[0].On;
                    g1 = Inputs[1].On;
                    g2 = Inputs[2].On;
                    g3 = Inputs[3].On;
                    g4 = Inputs[4].On;
                    g5 = Inputs[5].On;
                    g6 = Inputs[6].On;
                    g7 = Inputs[7].On;
                }
                a0 = g0;
                a1 = g1;
                a2 = g2;
                a3 = g3;
                a4 = g4;
                a5 = g5;
                a6 = g6;
                a7 = g7;
            }

            if (Inputs[9].On && Inputs[10].On && !Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    h0 = Inputs[0].On;
                    h1 = Inputs[1].On;
                    h2 = Inputs[2].On;
                    h3 = Inputs[3].On;
                    h4 = Inputs[4].On;
                    h5 = Inputs[5].On;
                    h6 = Inputs[6].On;
                    h7 = Inputs[7].On;
                }
                a0 = h0;
                a1 = h1;
                a2 = h2;
                a3 = h3;
                a4 = h4;
                a5 = h5;
                a6 = h6;
                a7 = h7;
            }

            if (Inputs[9].On && Inputs[10].On && Inputs[11].On)
            {
                if (Inputs[8].On)
                {
                    i0 = Inputs[0].On;
                    i1 = Inputs[1].On;
                    i2 = Inputs[2].On;
                    i3 = Inputs[3].On;
                    i4 = Inputs[4].On;
                    i5 = Inputs[5].On;
                    i6 = Inputs[6].On;
                    i7 = Inputs[7].On;
                }
                a0 = i0;
                a1 = i1;
                a2 = i2;
                a3 = i3;
                a4 = i4;
                a5 = i5;
                a6 = i6;
                a7 = i7;
            }

        Outputs[0].On = a0;
        Outputs[1].On = a1;
        Outputs[2].On = a2;
        Outputs[3].On = a3;
        Outputs[4].On = a4;
        Outputs[5].On = a5;
        Outputs[6].On = a6;
        Outputs[7].On = a7;

        }
    }
}