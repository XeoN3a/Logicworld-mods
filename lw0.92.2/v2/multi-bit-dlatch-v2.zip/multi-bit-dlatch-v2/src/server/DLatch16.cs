using LogicAPI.Server.Components;

namespace multi_bit_dlatch.Components
{
    public class DLatch16 : LogicComponent
    {
        private bool q0;
        private bool q1;
        private bool q2;
        private bool q3;
        private bool q4;
        private bool q5;
        private bool q6;
        private bool q7;
        private bool q8;
        private bool q9;
        private bool q10;
        private bool q11;
        private bool q12;
        private bool q13;
        private bool q14;
        private bool q15;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 15 = D0 - D15
            // 16 = Enable (top)

            bool enable = Inputs[16].On;

            if (enable)
            {
                q0 = Inputs[0].On;
                q1 = Inputs[1].On;
                q2 = Inputs[2].On;
                q3 = Inputs[3].On;
                q4 = Inputs[4].On;
                q5 = Inputs[5].On;
                q6 = Inputs[6].On;
                q7 = Inputs[7].On;
                q8 = Inputs[8].On;
                q9 = Inputs[9].On;
                q10 = Inputs[10].On;
                q11 = Inputs[11].On;
                q12 = Inputs[12].On;
                q13 = Inputs[13].On;
                q14 = Inputs[14].On;
                q15 = Inputs[15].On;
            }

            Outputs[0].On = q0;
            Outputs[1].On = q1;
            Outputs[2].On = q2;
            Outputs[3].On = q3;
            Outputs[4].On = q4;
            Outputs[5].On = q5;
            Outputs[6].On = q6;
            Outputs[7].On = q7;
            Outputs[8].On = q8;
            Outputs[9].On = q9;
            Outputs[10].On = q10;
            Outputs[11].On = q11;
            Outputs[12].On = q12;
            Outputs[13].On = q13;
            Outputs[14].On = q14;
            Outputs[15].On = q15;
        }
    }
}