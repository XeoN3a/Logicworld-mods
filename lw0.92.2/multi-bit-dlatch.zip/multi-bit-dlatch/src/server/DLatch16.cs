using LogicAPI.Server.Components;

namespace multi_bit_dlatch.Components
{
    public class DLatch16 : LogicComponent
    {
        private bool[] q = new bool[16];

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 15 = D0 - D15
            // 16 = Enable (top)

            bool enable = Inputs[16].On;

            if (enable)
            {
                for (int i = 0; i < 16; i++)
                {
                    q[i] = Inputs[i].On;
                }
            }

            for (int i = 0; i < 16; i++)
            {
                Outputs[i].On = q[i];
            }
        }
    }
}