using LogicAPI.Server.Components;

namespace multi_bit_dlatch.Components
{
    public class DLatch4 : LogicComponent
    {
        private bool q0;
        private bool q1;
        private bool q2;
        private bool q3;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 = D0
            // 1 = D1
            // 2 = D2
            // 3 = D3
            // 4 = Enable (top)

            bool enable = Inputs[4].On;

            if (enable)
            {
                q0 = Inputs[0].On;
                q1 = Inputs[1].On;
                q2 = Inputs[2].On;
                q3 = Inputs[3].On;
            }

            Outputs[0].On = q0;
            Outputs[1].On = q1;
            Outputs[2].On = q2;
            Outputs[3].On = q3;
        }
    }
}