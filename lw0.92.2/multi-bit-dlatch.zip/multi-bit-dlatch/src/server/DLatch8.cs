using LogicAPI.Server.Components;

namespace multi_bit_dlatch.Components
{
    public class DLatch8 : LogicComponent
    {
        private bool q0;
        private bool q1;
        private bool q2;
        private bool q3;
        private bool q4;
        private bool q5;
        private bool q6;
        private bool q7;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 7 = D0 - D7
            // 8 = Enable (top)

            bool enable = Inputs[8].On;

            if (enable)
            {
                q0 = Inputs[0].On;
                q1 = Inputs[1].On;
                q2 = Inputs[2].On;
                q3 = Inputs[3].On;
                q4 = Inputs[4].On;
                q5 = Inputs[5].On;
                q6 = Inputs[6].On;
                q7 = Inputs[7].On;
            }

            Outputs[0].On = q0;
            Outputs[1].On = q1;
            Outputs[2].On = q2;
            Outputs[3].On = q3;
            Outputs[4].On = q4;
            Outputs[5].On = q5;
            Outputs[6].On = q6;
            Outputs[7].On = q7;
        }
    }
}