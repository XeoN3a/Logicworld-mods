using LogicAPI.Server.Components;

namespace multi_bit_dlatch.Components
{
    public class DLatch2 : LogicComponent
    {
        private bool q0;
        private bool q1;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 = D0
            // 1 = D1
            // 2 = Enable (top)

            bool enable = Inputs[2].On;

            if (enable)
            {
                q0 = Inputs[0].On;
                q1 = Inputs[1].On;
            }

            Outputs[0].On = q0;
            Outputs[1].On = q1;
        }
    }
}