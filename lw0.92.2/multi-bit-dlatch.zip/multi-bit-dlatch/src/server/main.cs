using LogicAPI.Server;
using LogicLog;

namespace MultiBitDLatch
{
    public class MultiBitDLatch : ServerMod
    {
        protected override void Initialize()
        {
            Logger.Info("Multi-bit D Latch mod loaded successfully!");
        }
    }
}