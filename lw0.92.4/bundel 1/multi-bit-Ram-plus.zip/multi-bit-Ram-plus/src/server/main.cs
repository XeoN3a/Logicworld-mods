using LogicAPI.Server;
using LogicLog;

namespace multibitramplus
{
    public class multibitramplus : ServerMod
    {
        protected override void Initialize()
        {
            Logger.Info("Multi-bit Ram mod loaded successfully!");
        }
    }
}