using LogicAPI.Server.Components;

namespace multi_bit_ram_plus.Components
{
    public class Ram8Bit32A : LogicComponent
    {
        private bool a0;
        private bool a1;
        private bool a2;
        private bool a3;
        private bool a4;
        private bool a5;
        private bool a6;
        private bool a7;
        
        //g1
        private bool b1_0;
        private bool b1_1;
        private bool b1_2;
        private bool b1_3;
        private bool b1_4;
        private bool b1_5;
        private bool b1_6;
        private bool b1_7;

        private bool c1_0;
        private bool c1_1;
        private bool c1_2;
        private bool c1_3;
        private bool c1_4;
        private bool c1_5;
        private bool c1_6;
        private bool c1_7;

        private bool d1_0;
        private bool d1_1;
        private bool d1_2;
        private bool d1_3;
        private bool d1_4;
        private bool d1_5;
        private bool d1_6;
        private bool d1_7;

        private bool e1_0;
        private bool e1_1;
        private bool e1_2;
        private bool e1_3;
        private bool e1_4;
        private bool e1_5;
        private bool e1_6;
        private bool e1_7;
        
        //g2
        private bool b2_0;
        private bool b2_1;
        private bool b2_2;
        private bool b2_3;
        private bool b2_4;
        private bool b2_5;
        private bool b2_6;
        private bool b2_7;

        private bool c2_0;
        private bool c2_1;
        private bool c2_2;
        private bool c2_3;
        private bool c2_4;
        private bool c2_5;
        private bool c2_6;
        private bool c2_7;

        private bool d2_0;
        private bool d2_1;
        private bool d2_2;
        private bool d2_3;
        private bool d2_4;
        private bool d2_5;
        private bool d2_6;
        private bool d2_7;

        private bool e2_0;
        private bool e2_1;
        private bool e2_2;
        private bool e2_3;
        private bool e2_4;
        private bool e2_5;
        private bool e2_6;
        private bool e2_7;
        
        //g3
        private bool b3_0;
        private bool b3_1;
        private bool b3_2;
        private bool b3_3;
        private bool b3_4;
        private bool b3_5;
        private bool b3_6;
        private bool b3_7;

        private bool c3_0;
        private bool c3_1;
        private bool c3_2;
        private bool c3_3;
        private bool c3_4;
        private bool c3_5;
        private bool c3_6;
        private bool c3_7;

        private bool d3_0;
        private bool d3_1;
        private bool d3_2;
        private bool d3_3;
        private bool d3_4;
        private bool d3_5;
        private bool d3_6;
        private bool d3_7;

        private bool e3_0;
        private bool e3_1;
        private bool e3_2;
        private bool e3_3;
        private bool e3_4;
        private bool e3_5;
        private bool e3_6;
        private bool e3_7;
        
        //g4
        private bool b4_0;
        private bool b4_1;
        private bool b4_2;
        private bool b4_3;
        private bool b4_4;
        private bool b4_5;
        private bool b4_6;
        private bool b4_7;

        private bool c4_0;
        private bool c4_1;
        private bool c4_2;
        private bool c4_3;
        private bool c4_4;
        private bool c4_5;
        private bool c4_6;
        private bool c4_7;

        private bool d4_0;
        private bool d4_1;
        private bool d4_2;
        private bool d4_3;
        private bool d4_4;
        private bool d4_5;
        private bool d4_6;
        private bool d4_7;

        private bool e4_0;
        private bool e4_1;
        private bool e4_2;
        private bool e4_3;
        private bool e4_4;
        private bool e4_5;
        private bool e4_6;
        private bool e4_7;
        
        //g5
        private bool b5_0;
        private bool b5_1;
        private bool b5_2;
        private bool b5_3;
        private bool b5_4;
        private bool b5_5;
        private bool b5_6;
        private bool b5_7;

        private bool c5_0;
        private bool c5_1;
        private bool c5_2;
        private bool c5_3;
        private bool c5_4;
        private bool c5_5;
        private bool c5_6;
        private bool c5_7;

        private bool d5_0;
        private bool d5_1;
        private bool d5_2;
        private bool d5_3;
        private bool d5_4;
        private bool d5_5;
        private bool d5_6;
        private bool d5_7;

        private bool e5_0;
        private bool e5_1;
        private bool e5_2;
        private bool e5_3;
        private bool e5_4;
        private bool e5_5;
        private bool e5_6;
        private bool e5_7;
        
        //g6
        private bool b6_0;
        private bool b6_1;
        private bool b6_2;
        private bool b6_3;
        private bool b6_4;
        private bool b6_5;
        private bool b6_6;
        private bool b6_7;

        private bool c6_0;
        private bool c6_1;
        private bool c6_2;
        private bool c6_3;
        private bool c6_4;
        private bool c6_5;
        private bool c6_6;
        private bool c6_7;

        private bool d6_0;
        private bool d6_1;
        private bool d6_2;
        private bool d6_3;
        private bool d6_4;
        private bool d6_5;
        private bool d6_6;
        private bool d6_7;

        private bool e6_0;
        private bool e6_1;
        private bool e6_2;
        private bool e6_3;
        private bool e6_4;
        private bool e6_5;
        private bool e6_6;
        private bool e6_7;
        
        //g7
        private bool b7_0;
        private bool b7_1;
        private bool b7_2;
        private bool b7_3;
        private bool b7_4;
        private bool b7_5;
        private bool b7_6;
        private bool b7_7;

        private bool c7_0;
        private bool c7_1;
        private bool c7_2;
        private bool c7_3;
        private bool c7_4;
        private bool c7_5;
        private bool c7_6;
        private bool c7_7;

        private bool d7_0;
        private bool d7_1;
        private bool d7_2;
        private bool d7_3;
        private bool d7_4;
        private bool d7_5;
        private bool d7_6;
        private bool d7_7;

        private bool e7_0;
        private bool e7_1;
        private bool e7_2;
        private bool e7_3;
        private bool e7_4;
        private bool e7_5;
        private bool e7_6;
        private bool e7_7;
        
        //g8
        private bool b8_0;
        private bool b8_1;
        private bool b8_2;
        private bool b8_3;
        private bool b8_4;
        private bool b8_5;
        private bool b8_6;
        private bool b8_7;

        private bool c8_0;
        private bool c8_1;
        private bool c8_2;
        private bool c8_3;
        private bool c8_4;
        private bool c8_5;
        private bool c8_6;
        private bool c8_7;

        private bool d8_0;
        private bool d8_1;
        private bool d8_2;
        private bool d8_3;
        private bool d8_4;
        private bool d8_5;
        private bool d8_6;
        private bool d8_7;

        private bool e8_0;
        private bool e8_1;
        private bool e8_2;
        private bool e8_3;
        private bool e8_4;
        private bool e8_5;
        private bool e8_6;
        private bool e8_7;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 7 = D0 - D7
            // 8 = Enable (top)
            // 00000 = 00000-00011 =g1, 00100-00111 = g2, 01000-01011 =g3, 01100-01111 = g4, 10000-10011 =g5, 10100-10111 = g6, 11000-11011 =g7, 11100-11111 = g8
            // 9 - 13 = address bits
            
            if (!Inputs[13].On)
            {
                if (!Inputs[9].On && !Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b1_0 = Inputs[0].On;
                            b1_1 = Inputs[1].On;
                            b1_2 = Inputs[2].On;
                            b1_3 = Inputs[3].On;
                            b1_4 = Inputs[4].On;
                            b1_5 = Inputs[5].On;
                            b1_6 = Inputs[6].On;
                            b1_7 = Inputs[7].On;
                        }
                        a0 = b1_0;
                        a1 = b1_1;
                        a2 = b1_2;
                        a3 = b1_3;
                        a4 = b1_4;
                        a5 = b1_5;
                        a6 = b1_6;
                        a7 = b1_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c1_0 = Inputs[0].On;
                            c1_1 = Inputs[1].On;
                            c1_2 = Inputs[2].On;
                            c1_3 = Inputs[3].On;
                            c1_4 = Inputs[4].On;
                            c1_5 = Inputs[5].On;
                            c1_6 = Inputs[6].On;
                            c1_7 = Inputs[7].On;
                        }
                        a0 = c1_0;
                        a1 = c1_1;
                        a2 = c1_2;
                        a3 = c1_3;
                        a4 = c1_4;
                        a5 = c1_5;
                        a6 = c1_6;
                        a7 = c1_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d1_0 = Inputs[0].On;
                            d1_1 = Inputs[1].On;
                            d1_2 = Inputs[2].On;
                            d1_3 = Inputs[3].On;
                            d1_4 = Inputs[4].On;
                            d1_5 = Inputs[5].On;
                            d1_6 = Inputs[6].On;
                            d1_7 = Inputs[7].On;
                        }
                        a0 = d1_0;
                        a1 = d1_1;
                        a2 = d1_2;
                        a3 = d1_3;
                        a4 = d1_4;
                        a5 = d1_5;
                        a6 = d1_6;
                        a7 = d1_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e1_0 = Inputs[0].On;
                            e1_1 = Inputs[1].On;
                            e1_2 = Inputs[2].On;
                            e1_3 = Inputs[3].On;
                            e1_4 = Inputs[4].On;
                            e1_5 = Inputs[5].On;
                            e1_6 = Inputs[6].On;
                            e1_7 = Inputs[7].On;
                        }
                        a0 = e1_0;
                        a1 = e1_1;
                        a2 = e1_2;
                        a3 = e1_3;
                        a4 = e1_4;
                        a5 = e1_5;
                        a6 = e1_6;
                        a7 = e1_7;
                    }
                }

                if (!Inputs[9].On && Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b2_0 = Inputs[0].On;
                            b2_1 = Inputs[1].On;
                            b2_2 = Inputs[2].On;
                            b2_3 = Inputs[3].On;
                            b2_4 = Inputs[4].On;
                            b2_5 = Inputs[5].On;
                            b2_6 = Inputs[6].On;
                            b2_7 = Inputs[7].On;
                        }
                        a0 = b2_0;
                        a1 = b2_1;
                        a2 = b2_2;
                        a3 = b2_3;
                        a4 = b2_4;
                        a5 = b2_5;
                        a6 = b2_6;
                        a7 = b2_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c2_0 = Inputs[0].On;
                            c2_1 = Inputs[1].On;
                            c2_2 = Inputs[2].On;
                            c2_3 = Inputs[3].On;
                            c2_4 = Inputs[4].On;
                            c2_5 = Inputs[5].On;
                            c2_6 = Inputs[6].On;
                            c2_7 = Inputs[7].On;
                        }
                        a0 = c2_0;
                        a1 = c2_1;
                        a2 = c2_2;
                        a3 = c2_3;
                        a4 = c2_4;
                        a5 = c2_5;
                        a6 = c2_6;
                        a7 = c2_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d2_0 = Inputs[0].On;
                            d2_1 = Inputs[1].On;
                            d2_2 = Inputs[2].On;
                            d2_3 = Inputs[3].On;
                            d2_4 = Inputs[4].On;
                            d2_5 = Inputs[5].On;
                            d2_6 = Inputs[6].On;
                            d2_7 = Inputs[7].On;
                        }
                        a0 = d2_0;
                        a1 = d2_1;
                        a2 = d2_2;
                        a3 = d2_3;
                        a4 = d2_4;
                        a5 = d2_5;
                        a6 = d2_6;
                        a7 = d2_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e2_0 = Inputs[0].On;
                            e2_1 = Inputs[1].On;
                            e2_2 = Inputs[2].On;
                            e2_3 = Inputs[3].On;
                            e2_4 = Inputs[4].On;
                            e2_5 = Inputs[5].On;
                            e2_6 = Inputs[6].On;
                            e2_7 = Inputs[7].On;
                        }
                        a0 = e2_0;
                        a1 = e2_1;
                        a2 = e2_2;
                        a3 = e2_3;
                        a4 = e2_4;
                        a5 = e2_5;
                        a6 = e2_6;
                        a7 = e2_7;
                    }
                }

                if (Inputs[9].On && !Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b3_0 = Inputs[0].On;
                            b3_1 = Inputs[1].On;
                            b3_2 = Inputs[2].On;
                            b3_3 = Inputs[3].On;
                            b3_4 = Inputs[4].On;
                            b3_5 = Inputs[5].On;
                            b3_6 = Inputs[6].On;
                            b3_7 = Inputs[7].On;
                        }
                        a0 = b3_0;
                        a1 = b3_1;
                        a2 = b3_2;
                        a3 = b3_3;
                        a4 = b3_4;
                        a5 = b3_5;
                        a6 = b3_6;
                        a7 = b3_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c3_0 = Inputs[0].On;
                            c3_1 = Inputs[1].On;
                            c3_2 = Inputs[2].On;
                            c3_3 = Inputs[3].On;
                            c3_4 = Inputs[4].On;
                            c3_5 = Inputs[5].On;
                            c3_6 = Inputs[6].On;
                            c3_7 = Inputs[7].On;
                        }
                        a0 = c3_0;
                        a1 = c3_1;
                        a2 = c3_2;
                        a3 = c3_3;
                        a4 = c3_4;
                        a5 = c3_5;
                        a6 = c3_6;
                        a7 = c3_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d3_0 = Inputs[0].On;
                            d3_1 = Inputs[1].On;
                            d3_2 = Inputs[2].On;
                            d3_3 = Inputs[3].On;
                            d3_4 = Inputs[4].On;
                            d3_5 = Inputs[5].On;
                            d3_6 = Inputs[6].On;
                            d3_7 = Inputs[7].On;
                        }
                        a0 = d3_0;
                        a1 = d3_1;
                        a2 = d3_2;
                        a3 = d3_3;
                        a4 = d3_4;
                        a5 = d3_5;
                        a6 = d3_6;
                        a7 = d3_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e3_0 = Inputs[0].On;
                            e3_1 = Inputs[1].On;
                            e3_2 = Inputs[2].On;
                            e3_3 = Inputs[3].On;
                            e3_4 = Inputs[4].On;
                            e3_5 = Inputs[5].On;
                            e3_6 = Inputs[6].On;
                            e3_7 = Inputs[7].On;
                        }
                        a0 = e3_0;
                        a1 = e3_1;
                        a2 = e3_2;
                        a3 = e3_3;
                        a4 = e3_4;
                        a5 = e3_5;
                        a6 = e3_6;
                        a7 = e3_7;
                    }
                }

                if (Inputs[9].On && Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b4_0 = Inputs[0].On;
                            b4_1 = Inputs[1].On;
                            b4_2 = Inputs[2].On;
                            b4_3 = Inputs[3].On;
                            b4_4 = Inputs[4].On;
                            b4_5 = Inputs[5].On;
                            b4_6 = Inputs[6].On;
                            b4_7 = Inputs[7].On;
                        }
                        a0 = b4_0;
                        a1 = b4_1;
                        a2 = b4_2;
                        a3 = b4_3;
                        a4 = b4_4;
                        a5 = b4_5;
                        a6 = b4_6;
                        a7 = b4_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c4_0 = Inputs[0].On;
                            c4_1 = Inputs[1].On;
                            c4_2 = Inputs[2].On;
                            c4_3 = Inputs[3].On;
                            c4_4 = Inputs[4].On;
                            c4_5 = Inputs[5].On;
                            c4_6 = Inputs[6].On;
                            c4_7 = Inputs[7].On;
                        }
                        a0 = c4_0;
                        a1 = c4_1;
                        a2 = c4_2;
                        a3 = c4_3;
                        a4 = c4_4;
                        a5 = c4_5;
                        a6 = c4_6;
                        a7 = c4_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d4_0 = Inputs[0].On;
                            d4_1 = Inputs[1].On;
                            d4_2 = Inputs[2].On;
                            d4_3 = Inputs[3].On;
                            d4_4 = Inputs[4].On;
                            d4_5 = Inputs[5].On;
                            d4_6 = Inputs[6].On;
                            d4_7 = Inputs[7].On;
                        }
                        a0 = d4_0;
                        a1 = d4_1;
                        a2 = d4_2;
                        a3 = d4_3;
                        a4 = d4_4;
                        a5 = d4_5;
                        a6 = d4_6;
                        a7 = d4_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e4_0 = Inputs[0].On;
                            e4_1 = Inputs[1].On;
                            e4_2 = Inputs[2].On;
                            e4_3 = Inputs[3].On;
                            e4_4 = Inputs[4].On;
                            e4_5 = Inputs[5].On;
                            e4_6 = Inputs[6].On;
                            e4_7 = Inputs[7].On;
                        }
                        a0 = e4_0;
                        a1 = e4_1;
                        a2 = e4_2;
                        a3 = e4_3;
                        a4 = e4_4;
                        a5 = e4_5;
                        a6 = e4_6;
                        a7 = e4_7;
                    }
                }
            }

            if (Inputs[13].On)
            {
                if (!Inputs[9].On && !Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b5_0 = Inputs[0].On;
                            b5_1 = Inputs[1].On;
                            b5_2 = Inputs[2].On;
                            b5_3 = Inputs[3].On;
                            b5_4 = Inputs[4].On;
                            b5_5 = Inputs[5].On;
                            b5_6 = Inputs[6].On;
                            b5_7 = Inputs[7].On;
                        }
                        a0 = b5_0;
                        a1 = b5_1;
                        a2 = b5_2;
                        a3 = b5_3;
                        a4 = b5_4;
                        a5 = b5_5;
                        a6 = b5_6;
                        a7 = b5_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c5_0 = Inputs[0].On;
                            c5_1 = Inputs[1].On;
                            c5_2 = Inputs[2].On;
                            c5_3 = Inputs[3].On;
                            c5_4 = Inputs[4].On;
                            c5_5 = Inputs[5].On;
                            c5_6 = Inputs[6].On;
                            c5_7 = Inputs[7].On;
                        }
                        a0 = c5_0;
                        a1 = c5_1;
                        a2 = c5_2;
                        a3 = c5_3;
                        a4 = c5_4;
                        a5 = c5_5;
                        a6 = c5_6;
                        a7 = c5_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d5_0 = Inputs[0].On;
                            d5_1 = Inputs[1].On;
                            d5_2 = Inputs[2].On;
                            d5_3 = Inputs[3].On;
                            d5_4 = Inputs[4].On;
                            d5_5 = Inputs[5].On;
                            d5_6 = Inputs[6].On;
                            d5_7 = Inputs[7].On;
                        }
                        a0 = d5_0;
                        a1 = d5_1;
                        a2 = d5_2;
                        a3 = d5_3;
                        a4 = d5_4;
                        a5 = d5_5;
                        a6 = d5_6;
                        a7 = d5_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e5_0 = Inputs[0].On;
                            e5_1 = Inputs[1].On;
                            e5_2 = Inputs[2].On;
                            e5_3 = Inputs[3].On;
                            e5_4 = Inputs[4].On;
                            e5_5 = Inputs[5].On;
                            e5_6 = Inputs[6].On;
                            e5_7 = Inputs[7].On;
                        }
                        a0 = e5_0;
                        a1 = e5_1;
                        a2 = e5_2;
                        a3 = e5_3;
                        a4 = e5_4;
                        a5 = e5_5;
                        a6 = e5_6;
                        a7 = e5_7;
                    }
                }

                if (!Inputs[9].On && Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b6_0 = Inputs[0].On;
                            b6_1 = Inputs[1].On;
                            b6_2 = Inputs[2].On;
                            b6_3 = Inputs[3].On;
                            b6_4 = Inputs[4].On;
                            b6_5 = Inputs[5].On;
                            b6_6 = Inputs[6].On;
                            b6_7 = Inputs[7].On;
                        }
                        a0 = b6_0;
                        a1 = b6_1;
                        a2 = b6_2;
                        a3 = b6_3;
                        a4 = b6_4;
                        a5 = b6_5;
                        a6 = b6_6;
                        a7 = b6_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c6_0 = Inputs[0].On;
                            c6_1 = Inputs[1].On;
                            c6_2 = Inputs[2].On;
                            c6_3 = Inputs[3].On;
                            c6_4 = Inputs[4].On;
                            c6_5 = Inputs[5].On;
                            c6_6 = Inputs[6].On;
                            c6_7 = Inputs[7].On;
                        }
                        a0 = c6_0;
                        a1 = c6_1;
                        a2 = c6_2;
                        a3 = c6_3;
                        a4 = c6_4;
                        a5 = c6_5;
                        a6 = c6_6;
                        a7 = c6_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d6_0 = Inputs[0].On;
                            d6_1 = Inputs[1].On;
                            d6_2 = Inputs[2].On;
                            d6_3 = Inputs[3].On;
                            d6_4 = Inputs[4].On;
                            d6_5 = Inputs[5].On;
                            d6_6 = Inputs[6].On;
                            d6_7 = Inputs[7].On;
                        }
                        a0 = d6_0;
                        a1 = d6_1;
                        a2 = d6_2;
                        a3 = d6_3;
                        a4 = d6_4;
                        a5 = d6_5;
                        a6 = d6_6;
                        a7 = d6_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e6_0 = Inputs[0].On;
                            e6_1 = Inputs[1].On;
                            e6_2 = Inputs[2].On;
                            e6_3 = Inputs[3].On;
                            e6_4 = Inputs[4].On;
                            e6_5 = Inputs[5].On;
                            e6_6 = Inputs[6].On;
                            e6_7 = Inputs[7].On;
                        }
                        a0 = e6_0;
                        a1 = e6_1;
                        a2 = e6_2;
                        a3 = e6_3;
                        a4 = e6_4;
                        a5 = e6_5;
                        a6 = e6_6;
                        a7 = e6_7;
                    }
                }
                
                if (Inputs[9].On && !Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b7_0 = Inputs[0].On;
                            b7_1 = Inputs[1].On;
                            b7_2 = Inputs[2].On;
                            b7_3 = Inputs[3].On;
                            b7_4 = Inputs[4].On;
                            b7_5 = Inputs[5].On;
                            b7_6 = Inputs[6].On;
                            b7_7 = Inputs[7].On;
                        }
                        a0 = b7_0;
                        a1 = b7_1;
                        a2 = b7_2;
                        a3 = b7_3;
                        a4 = b7_4;
                        a5 = b7_5;
                        a6 = b7_6;
                        a7 = b7_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c7_0 = Inputs[0].On;
                            c7_1 = Inputs[1].On;
                            c7_2 = Inputs[2].On;
                            c7_3 = Inputs[3].On;
                            c7_4 = Inputs[4].On;
                            c7_5 = Inputs[5].On;
                            c7_6 = Inputs[6].On;
                            c7_7 = Inputs[7].On;
                        }
                        a0 = c7_0;
                        a1 = c7_1;
                        a2 = c7_2;
                        a3 = c7_3;
                        a4 = c7_4;
                        a5 = c7_5;
                        a6 = c7_6;
                        a7 = c7_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d7_0 = Inputs[0].On;
                            d7_1 = Inputs[1].On;
                            d7_2 = Inputs[2].On;
                            d7_3 = Inputs[3].On;
                            d7_4 = Inputs[4].On;
                            d7_5 = Inputs[5].On;
                            d7_6 = Inputs[6].On;
                            d7_7 = Inputs[7].On;
                        }
                        a0 = d7_0;
                        a1 = d7_1;
                        a2 = d7_2;
                        a3 = d7_3;
                        a4 = d7_4;
                        a5 = d7_5;
                        a6 = d7_6;
                        a7 = d7_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e7_0 = Inputs[0].On;
                            e7_1 = Inputs[1].On;
                            e7_2 = Inputs[2].On;
                            e7_3 = Inputs[3].On;
                            e7_4 = Inputs[4].On;
                            e7_5 = Inputs[5].On;
                            e7_6 = Inputs[6].On;
                            e7_7 = Inputs[7].On;
                        }
                        a0 = e7_0;
                        a1 = e7_1;
                        a2 = e7_2;
                        a3 = e7_3;
                        a4 = e7_4;
                        a5 = e7_5;
                        a6 = e7_6;
                        a7 = e7_7;
                    }
                }
                
                if (Inputs[9].On && Inputs[10].On)
                {
                    if (!Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            b8_0 = Inputs[0].On;
                            b8_1 = Inputs[1].On;
                            b8_2 = Inputs[2].On;
                            b8_3 = Inputs[3].On;
                            b8_4 = Inputs[4].On;
                            b8_5 = Inputs[5].On;
                            b8_6 = Inputs[6].On;
                            b8_7 = Inputs[7].On;
                        }
                        a0 = b8_0;
                        a1 = b8_1;
                        a2 = b8_2;
                        a3 = b8_3;
                        a4 = b8_4;
                        a5 = b8_5;
                        a6 = b8_6;
                        a7 = b8_7;
                    }
                    if (!Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            c8_0 = Inputs[0].On;
                            c8_1 = Inputs[1].On;
                            c8_2 = Inputs[2].On;
                            c8_3 = Inputs[3].On;
                            c8_4 = Inputs[4].On;
                            c8_5 = Inputs[5].On;
                            c8_6 = Inputs[6].On;
                            c8_7 = Inputs[7].On;
                        }
                        a0 = c8_0;
                        a1 = c8_1;
                        a2 = c8_2;
                        a3 = c8_3;
                        a4 = c8_4;
                        a5 = c8_5;
                        a6 = c8_6;
                        a7 = c8_7;
                    }
                    if (Inputs[11].On && !Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            d8_0 = Inputs[0].On;
                            d8_1 = Inputs[1].On;
                            d8_2 = Inputs[2].On;
                            d8_3 = Inputs[3].On;
                            d8_4 = Inputs[4].On;
                            d8_5 = Inputs[5].On;
                            d8_6 = Inputs[6].On;
                            d8_7 = Inputs[7].On;
                        }
                        a0 = d8_0;
                        a1 = d8_1;
                        a2 = d8_2;
                        a3 = d8_3;
                        a4 = d8_4;
                        a5 = d8_5;
                        a6 = d8_6;
                        a7 = d8_7;
                    }
                    if (Inputs[11].On && Inputs[12].On)
                    {
                        if (Inputs[8].On)
                        {
                            e8_0 = Inputs[0].On;
                            e8_1 = Inputs[1].On;
                            e8_2 = Inputs[2].On;
                            e8_3 = Inputs[3].On;
                            e8_4 = Inputs[4].On;
                            e8_5 = Inputs[5].On;
                            e8_6 = Inputs[6].On;
                            e8_7 = Inputs[7].On;
                        }
                        a0 = e8_0;
                        a1 = e8_1;
                        a2 = e8_2;
                        a3 = e8_3;
                        a4 = e8_4;
                        a5 = e8_5;
                        a6 = e8_6;
                        a7 = e8_7;
                    }
                }
            }

        Outputs[0].On = a0;
        Outputs[1].On = a1;
        Outputs[2].On = a2;
        Outputs[3].On = a3;
        Outputs[4].On = a4;
        Outputs[5].On = a5;
        Outputs[6].On = a6;
        Outputs[7].On = a7;

        }
    }
}