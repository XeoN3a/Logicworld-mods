using LogicAPI.Server.Components;

namespace multi_bit_ram_plus.Components
{
    public class Ram8Bit16A : LogicComponent
    {
        private bool a0;
        private bool a1;
        private bool a2;
        private bool a3;
        private bool a4;
        private bool a5;
        private bool a6;
        private bool a7;
        
        //g1
        private bool b1_0;
        private bool b1_1;
        private bool b1_2;
        private bool b1_3;
        private bool b1_4;
        private bool b1_5;
        private bool b1_6;
        private bool b1_7;

        private bool c1_0;
        private bool c1_1;
        private bool c1_2;
        private bool c1_3;
        private bool c1_4;
        private bool c1_5;
        private bool c1_6;
        private bool c1_7;

        private bool d1_0;
        private bool d1_1;
        private bool d1_2;
        private bool d1_3;
        private bool d1_4;
        private bool d1_5;
        private bool d1_6;
        private bool d1_7;

        private bool e1_0;
        private bool e1_1;
        private bool e1_2;
        private bool e1_3;
        private bool e1_4;
        private bool e1_5;
        private bool e1_6;
        private bool e1_7;
        
        //g2
        private bool b2_0;
        private bool b2_1;
        private bool b2_2;
        private bool b2_3;
        private bool b2_4;
        private bool b2_5;
        private bool b2_6;
        private bool b2_7;

        private bool c2_0;
        private bool c2_1;
        private bool c2_2;
        private bool c2_3;
        private bool c2_4;
        private bool c2_5;
        private bool c2_6;
        private bool c2_7;

        private bool d2_0;
        private bool d2_1;
        private bool d2_2;
        private bool d2_3;
        private bool d2_4;
        private bool d2_5;
        private bool d2_6;
        private bool d2_7;

        private bool e2_0;
        private bool e2_1;
        private bool e2_2;
        private bool e2_3;
        private bool e2_4;
        private bool e2_5;
        private bool e2_6;
        private bool e2_7;
        
        //g3
        private bool b3_0;
        private bool b3_1;
        private bool b3_2;
        private bool b3_3;
        private bool b3_4;
        private bool b3_5;
        private bool b3_6;
        private bool b3_7;

        private bool c3_0;
        private bool c3_1;
        private bool c3_2;
        private bool c3_3;
        private bool c3_4;
        private bool c3_5;
        private bool c3_6;
        private bool c3_7;

        private bool d3_0;
        private bool d3_1;
        private bool d3_2;
        private bool d3_3;
        private bool d3_4;
        private bool d3_5;
        private bool d3_6;
        private bool d3_7;

        private bool e3_0;
        private bool e3_1;
        private bool e3_2;
        private bool e3_3;
        private bool e3_4;
        private bool e3_5;
        private bool e3_6;
        private bool e3_7;
        
        //g4
        private bool b4_0;
        private bool b4_1;
        private bool b4_2;
        private bool b4_3;
        private bool b4_4;
        private bool b4_5;
        private bool b4_6;
        private bool b4_7;

        private bool c4_0;
        private bool c4_1;
        private bool c4_2;
        private bool c4_3;
        private bool c4_4;
        private bool c4_5;
        private bool c4_6;
        private bool c4_7;

        private bool d4_0;
        private bool d4_1;
        private bool d4_2;
        private bool d4_3;
        private bool d4_4;
        private bool d4_5;
        private bool d4_6;
        private bool d4_7;

        private bool e4_0;
        private bool e4_1;
        private bool e4_2;
        private bool e4_3;
        private bool e4_4;
        private bool e4_5;
        private bool e4_6;
        private bool e4_7;

        protected override void DoLogicUpdate()
        {
            // Inputs:
            // 0 - 7 = D0 - D7
            // 8 = Enable (top)
            // 0000 = 0000-0011 =g1, 0100-0111 = g2, 1000-1011 =g3, 1100-1111 = g4
            // 9 - 12 = address bits
            
            if (!Inputs[9].On && !Inputs[10].On)
            {
                if (!Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        b1_0 = Inputs[0].On;
                        b1_1 = Inputs[1].On;
                        b1_2 = Inputs[2].On;
                        b1_3 = Inputs[3].On;
                        b1_4 = Inputs[4].On;
                        b1_5 = Inputs[5].On;
                        b1_6 = Inputs[6].On;
                        b1_7 = Inputs[7].On;
                    }
                    a0 = b1_0;
                    a1 = b1_1;
                    a2 = b1_2;
                    a3 = b1_3;
                    a4 = b1_4;
                    a5 = b1_5;
                    a6 = b1_6;
                    a7 = b1_7;
                }
                if (!Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        c1_0 = Inputs[0].On;
                        c1_1 = Inputs[1].On;
                        c1_2 = Inputs[2].On;
                        c1_3 = Inputs[3].On;
                        c1_4 = Inputs[4].On;
                        c1_5 = Inputs[5].On;
                        c1_6 = Inputs[6].On;
                        c1_7 = Inputs[7].On;
                    }
                    a0 = c1_0;
                    a1 = c1_1;
                    a2 = c1_2;
                    a3 = c1_3;
                    a4 = c1_4;
                    a5 = c1_5;
                    a6 = c1_6;
                    a7 = c1_7;
                }
                if (Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        d1_0 = Inputs[0].On;
                        d1_1 = Inputs[1].On;
                        d1_2 = Inputs[2].On;
                        d1_3 = Inputs[3].On;
                        d1_4 = Inputs[4].On;
                        d1_5 = Inputs[5].On;
                        d1_6 = Inputs[6].On;
                        d1_7 = Inputs[7].On;
                    }
                    a0 = d1_0;
                    a1 = d1_1;
                    a2 = d1_2;
                    a3 = d1_3;
                    a4 = d1_4;
                    a5 = d1_5;
                    a6 = d1_6;
                    a7 = d1_7;
                }
                if (Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        e1_0 = Inputs[0].On;
                        e1_1 = Inputs[1].On;
                        e1_2 = Inputs[2].On;
                        e1_3 = Inputs[3].On;
                        e1_4 = Inputs[4].On;
                        e1_5 = Inputs[5].On;
                        e1_6 = Inputs[6].On;
                        e1_7 = Inputs[7].On;
                    }
                    a0 = e1_0;
                    a1 = e1_1;
                    a2 = e1_2;
                    a3 = e1_3;
                    a4 = e1_4;
                    a5 = e1_5;
                    a6 = e1_6;
                    a7 = e1_7;
                }
            }

            if (!Inputs[9].On && Inputs[10].On)
            {
                if (!Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        b2_0 = Inputs[0].On;
                        b2_1 = Inputs[1].On;
                        b2_2 = Inputs[2].On;
                        b2_3 = Inputs[3].On;
                        b2_4 = Inputs[4].On;
                        b2_5 = Inputs[5].On;
                        b2_6 = Inputs[6].On;
                        b2_7 = Inputs[7].On;
                    }
                    a0 = b2_0;
                    a1 = b2_1;
                    a2 = b2_2;
                    a3 = b2_3;
                    a4 = b2_4;
                    a5 = b2_5;
                    a6 = b2_6;
                    a7 = b2_7;
                }
                if (!Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        c2_0 = Inputs[0].On;
                        c2_1 = Inputs[1].On;
                        c2_2 = Inputs[2].On;
                        c2_3 = Inputs[3].On;
                        c2_4 = Inputs[4].On;
                        c2_5 = Inputs[5].On;
                        c2_6 = Inputs[6].On;
                        c2_7 = Inputs[7].On;
                    }
                    a0 = c2_0;
                    a1 = c2_1;
                    a2 = c2_2;
                    a3 = c2_3;
                    a4 = c2_4;
                    a5 = c2_5;
                    a6 = c2_6;
                    a7 = c2_7;
                }
                if (Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        d2_0 = Inputs[0].On;
                        d2_1 = Inputs[1].On;
                        d2_2 = Inputs[2].On;
                        d2_3 = Inputs[3].On;
                        d2_4 = Inputs[4].On;
                        d2_5 = Inputs[5].On;
                        d2_6 = Inputs[6].On;
                        d2_7 = Inputs[7].On;
                    }
                    a0 = d2_0;
                    a1 = d2_1;
                    a2 = d2_2;
                    a3 = d2_3;
                    a4 = d2_4;
                    a5 = d2_5;
                    a6 = d2_6;
                    a7 = d2_7;
                }
                if (Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        e2_0 = Inputs[0].On;
                        e2_1 = Inputs[1].On;
                        e2_2 = Inputs[2].On;
                        e2_3 = Inputs[3].On;
                        e2_4 = Inputs[4].On;
                        e2_5 = Inputs[5].On;
                        e2_6 = Inputs[6].On;
                        e2_7 = Inputs[7].On;
                    }
                    a0 = e2_0;
                    a1 = e2_1;
                    a2 = e2_2;
                    a3 = e2_3;
                    a4 = e2_4;
                    a5 = e2_5;
                    a6 = e2_6;
                    a7 = e2_7;
                }
            }

            if (Inputs[9].On && !Inputs[10].On)
            {
                if (!Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        b3_0 = Inputs[0].On;
                        b3_1 = Inputs[1].On;
                        b3_2 = Inputs[2].On;
                        b3_3 = Inputs[3].On;
                        b3_4 = Inputs[4].On;
                        b3_5 = Inputs[5].On;
                        b3_6 = Inputs[6].On;
                        b3_7 = Inputs[7].On;
                    }
                    a0 = b3_0;
                    a1 = b3_1;
                    a2 = b3_2;
                    a3 = b3_3;
                    a4 = b3_4;
                    a5 = b3_5;
                    a6 = b3_6;
                    a7 = b3_7;
                }
                if (!Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        c3_0 = Inputs[0].On;
                        c3_1 = Inputs[1].On;
                        c3_2 = Inputs[2].On;
                        c3_3 = Inputs[3].On;
                        c3_4 = Inputs[4].On;
                        c3_5 = Inputs[5].On;
                        c3_6 = Inputs[6].On;
                        c3_7 = Inputs[7].On;
                    }
                    a0 = c3_0;
                    a1 = c3_1;
                    a2 = c3_2;
                    a3 = c3_3;
                    a4 = c3_4;
                    a5 = c3_5;
                    a6 = c3_6;
                    a7 = c3_7;
                }
                if (Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        d3_0 = Inputs[0].On;
                        d3_1 = Inputs[1].On;
                        d3_2 = Inputs[2].On;
                        d3_3 = Inputs[3].On;
                        d3_4 = Inputs[4].On;
                        d3_5 = Inputs[5].On;
                        d3_6 = Inputs[6].On;
                        d3_7 = Inputs[7].On;
                    }
                    a0 = d3_0;
                    a1 = d3_1;
                    a2 = d3_2;
                    a3 = d3_3;
                    a4 = d3_4;
                    a5 = d3_5;
                    a6 = d3_6;
                    a7 = d3_7;
                }
                if (Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        e3_0 = Inputs[0].On;
                        e3_1 = Inputs[1].On;
                        e3_2 = Inputs[2].On;
                        e3_3 = Inputs[3].On;
                        e3_4 = Inputs[4].On;
                        e3_5 = Inputs[5].On;
                        e3_6 = Inputs[6].On;
                        e3_7 = Inputs[7].On;
                    }
                    a0 = e3_0;
                    a1 = e3_1;
                    a2 = e3_2;
                    a3 = e3_3;
                    a4 = e3_4;
                    a5 = e3_5;
                    a6 = e3_6;
                    a7 = e3_7;
                }
            }

            if (Inputs[9].On && Inputs[10].On)
            {
                if (!Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        b4_0 = Inputs[0].On;
                        b4_1 = Inputs[1].On;
                        b4_2 = Inputs[2].On;
                        b4_3 = Inputs[3].On;
                        b4_4 = Inputs[4].On;
                        b4_5 = Inputs[5].On;
                        b4_6 = Inputs[6].On;
                        b4_7 = Inputs[7].On;
                    }
                    a0 = b4_0;
                    a1 = b4_1;
                    a2 = b4_2;
                    a3 = b4_3;
                    a4 = b4_4;
                    a5 = b4_5;
                    a6 = b4_6;
                    a7 = b4_7;
                }
                if (!Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        c4_0 = Inputs[0].On;
                        c4_1 = Inputs[1].On;
                        c4_2 = Inputs[2].On;
                        c4_3 = Inputs[3].On;
                        c4_4 = Inputs[4].On;
                        c4_5 = Inputs[5].On;
                        c4_6 = Inputs[6].On;
                        c4_7 = Inputs[7].On;
                    }
                    a0 = c4_0;
                    a1 = c4_1;
                    a2 = c4_2;
                    a3 = c4_3;
                    a4 = c4_4;
                    a5 = c4_5;
                    a6 = c4_6;
                    a7 = c4_7;
                }
                if (Inputs[11].On && !Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        d4_0 = Inputs[0].On;
                        d4_1 = Inputs[1].On;
                        d4_2 = Inputs[2].On;
                        d4_3 = Inputs[3].On;
                        d4_4 = Inputs[4].On;
                        d4_5 = Inputs[5].On;
                        d4_6 = Inputs[6].On;
                        d4_7 = Inputs[7].On;
                    }
                    a0 = d4_0;
                    a1 = d4_1;
                    a2 = d4_2;
                    a3 = d4_3;
                    a4 = d4_4;
                    a5 = d4_5;
                    a6 = d4_6;
                    a7 = d4_7;
                }
                if (Inputs[11].On && Inputs[12].On)
                {
                    if (Inputs[8].On)
                    {
                        e4_0 = Inputs[0].On;
                        e4_1 = Inputs[1].On;
                        e4_2 = Inputs[2].On;
                        e4_3 = Inputs[3].On;
                        e4_4 = Inputs[4].On;
                        e4_5 = Inputs[5].On;
                        e4_6 = Inputs[6].On;
                        e4_7 = Inputs[7].On;
                    }
                    a0 = e4_0;
                    a1 = e4_1;
                    a2 = e4_2;
                    a3 = e4_3;
                    a4 = e4_4;
                    a5 = e4_5;
                    a6 = e4_6;
                    a7 = e4_7;
                }
            }

        Outputs[0].On = a0;
        Outputs[1].On = a1;
        Outputs[2].On = a2;
        Outputs[3].On = a3;
        Outputs[4].On = a4;
        Outputs[5].On = a5;
        Outputs[6].On = a6;
        Outputs[7].On = a7;

        }
    }
}